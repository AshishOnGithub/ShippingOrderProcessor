﻿using System;
using System.Collections.Generic;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BusinessRuleEngine
{
    public class OrderProcessor
    {
        Payment _payment;
        public OrderProcessor(Payment payment)
        {
            _payment = payment;
        }
        // Function to process customer order
        public bool ProcessOrder(List<ProductDetails> orderdetails, string shippingAddress)
        {
            bool result = false;
            // Saving order details with shipping Address in table with disabled field.
            int totalprice = 0;
            List<int> productIds = new List<int>();
            foreach (ProductDetails product in orderdetails)
            {
                totalprice = totalprice + product.productValue;
                productIds.Add(product.productId);
            }

            result = _payment.ProcessPayment(productIds, totalprice);
            Console.WriteLine("Congratulatulations Order Processed succefully");
            // Updating order details with shipping Address in table with Enabled field.

            return result;

        }

    }

}
