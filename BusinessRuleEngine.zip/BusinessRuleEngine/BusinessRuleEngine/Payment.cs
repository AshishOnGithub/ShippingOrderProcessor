﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace BusinessRuleEngine
{
    public class Payment
    {
        // Function to process customer payment.
        public bool ProcessPayment(List<int> productIds, int totalCost)
        {
            Console.WriteLine("Please wait, Processing payment");
            Thread.Sleep(3000); // Calling third party api for payment.
            Console.WriteLine("Payment processed");

            return true;

        }

    }
}
