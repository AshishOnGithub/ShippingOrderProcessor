using NUnit.Framework;
using BusinessRuleEngine;
using System.Runtime.InteropServices;
using System.Collections.Generic;

namespace BusinessRuleEngineTests
{
    public class OrderTests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void ProcessOrder()
        {
            Payment payment = new Payment();
            List<ProductDetails> orderdetails = new List<ProductDetails>();
            orderdetails.Add(new ProductDetails { productId = 2, productName = "Book", productValue = 300 });
            orderdetails.Add(new ProductDetails { productId = 3, productName = "Membership", productValue = 1000 });

            string shippingAddress = "Anand VIhar, Delhi, India";
            OrderProcessor processor = new OrderProcessor(payment);
            Assert.True(processor.ProcessOrder(orderdetails, shippingAddress));
        }
    }
}