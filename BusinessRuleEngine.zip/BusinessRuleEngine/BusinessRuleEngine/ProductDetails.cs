﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessRuleEngine
{
    public class ProductDetails
    {
        public int productId;
        public string productName;
        public int productValue;
    }
}
