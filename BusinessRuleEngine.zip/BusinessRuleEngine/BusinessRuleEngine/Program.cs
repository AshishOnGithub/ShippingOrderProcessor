﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Tracing;

namespace BusinessRuleEngine
{
    class Program
    {
        static void Main(string[] args)
        {
            // List to save customer multiple order at once.
            List <ProductDetails> details = new List<ProductDetails>();
            Payment payment = new Payment();
            while(true)
            {
                Console.WriteLine("Welcome to Ashish shipping order System");
                
                Console.WriteLine("1. Physical, product. Price: Rs 200");
                Console.WriteLine("2. Book, Price: Rs 300");
                Console.WriteLine("3. Membership, Price Rs 1000");
                Console.WriteLine("4. Upgrade Membership, Price Rs 500");
                Console.WriteLine("5. Membership or upgrade, Price Rs 1500");
                Console.WriteLine("6. Video, Price Rs 2000");
                Console.WriteLine("7. Checkout.");
                Console.WriteLine("8. Exit.");

                int counter = 1;
                if (details.Count > 0)
                {
                    Console.WriteLine("");
                    Console.WriteLine("Items in your cart");
                    foreach (ProductDetails product in details)
                    {
                        Console.WriteLine(counter+" : "+product.productName);
                        counter++;
                    }
                }


                Console.WriteLine("PLease select one item to continue");
                int productId =Convert.ToInt32(Console.ReadLine());

                if (productId == 7)
                {
                    Console.WriteLine("Please enter shipping address");
                    string shippingAddress = Console.ReadLine();
                    OrderProcessor orderProcessor = new OrderProcessor(payment);
                    orderProcessor.ProcessOrder(details, shippingAddress);
                    break;
                }
                if (productId == 8)
                {
                    break;
                }

                switch (productId)
                {
                    case 1:
                        details.Add(new ProductDetails { productId = 1, productName = "physical", productValue = 200 });
                        break;
                    case 2:
                        details.Add(new ProductDetails { productId = 2, productName = "Book", productValue = 300 });
                        break;
                    case 3:
                        details.Add(new ProductDetails { productId = 3, productName = "Membership", productValue = 1000 });
                        break;
                    case 4:
                        details.Add(new ProductDetails { productId = 4, productName = "Upgrade membership", productValue = 500 });
                        break;
                    case 5:
                        details.Add(new ProductDetails { productId = 5, productName = "Membership or Upgrade", productValue = 1500 });
                        break;
                    case 6:
                        details.Add(new ProductDetails { productId = 6, productName = "Video", productValue = 2000 });
                        break;
                }

            }

        }
    }
}
